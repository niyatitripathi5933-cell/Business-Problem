import joblib
import pandas as pd
import numpy as np
import yaml
from pathlib import Path

class HousePricePredictor:
    def __init__(self, model_path='models/best_model.joblib', 
                 preprocessor_path='models/preprocessor.joblib'):
        self.model = joblib.load(model_path)
        self.preprocessor = joblib.load(preprocessor_path)
        self.feature_names = self.preprocessor.get_feature_names_out()
    
    def predict(self, input_data):
        """
        Predict house price
        
        input_data: dict with keys ['Area', 'Bedrooms', 'Bathrooms', 'Age', 
                                   'Location', 'Property_Type']
        """
        try:
            # Validate input
            required_features = ['Area', 'Bedrooms', 'Bathrooms', 'Age', 'Location', 'Property_Type']
            for feat in required_features:
                if feat not in input_data:
                    raise ValueError(f"Missing feature: {feat}")
            
            # Create DataFrame
            input_df = pd.DataFrame([input_data])
            
            # Feature engineering (same as training)
            input_df['area_per_bedroom'] = input_df['Area'] / (input_df['Bedrooms'] + 1)
            input_df['bath_per_bed'] = input_df['Bathrooms'] / (input_df['Bedrooms'] + 1)
            input_df['age_category'] = pd.cut(input_df['Age'], 
                                            bins=[-1, 5, 15, 30, 100], 
                                            labels=['New', 'Recent', 'Mature', 'Old'])
            
            # Preprocess
            X_processed = self.preprocessor.transform(input_df)
            
            # Predict
            price = self.model.predict(X_processed)[0]
            
            # Confidence (std from multiple predictions or model uncertainty)
            # For tree models, use prediction interval approximation
            if hasattr(self.model, 'predict_quantile'):
                pred_lower = self.model.predict_quantile(X_processed, alpha=0.05)[0]
                pred_upper = self.model.predict_quantile(X_processed, alpha=0.95)[0]
            else:
                # Simple approximation: ±2*MAE from validation
                confidence_interval = 800000  # From training
                pred_lower = max(0, price - confidence_interval)
                pred_upper = price + confidence_interval
            
            return {
                'predicted_price': round(price, -3),  # Round to nearest thousand
                'confidence_lower': round(pred_lower, -3),
                'confidence_upper': round(pred_upper, -3),
                'features': dict(zip(['Area', 'Bedrooms', 'Bathrooms', 'Age', 'Location', 'Property_Type'], 
                                   input_data.values()))
            }
        
        except Exception as e:
            return {'error': str(e)}
    
    def batch_predict(self, input_data_list):
        """Predict multiple houses"""
        predictions = []
        for data in input_data_list:
            predictions.append(self.predict(data))
        return predictions

if __name__ == "__main__":
    # Example usage
    predictor = HousePricePredictor()
    
    sample_house = {
        'Area': 2000,
        'Bedrooms': 3,
        'Bathrooms': 2,
        'Age': 10,
        'Location': 'City Center',
        'Property_Type': 'Apartment'
    }
    
    result = predictor.predict(sample_house)
    print(f"Prediction: ₹{result['predicted_price']/1e5:.1f} Lakhs")
    print(f"Confidence: ₹{result['confidence_lower']/1e5:.1f}L - ₹{result['confidence_upper']/1e5:.1f}L")

