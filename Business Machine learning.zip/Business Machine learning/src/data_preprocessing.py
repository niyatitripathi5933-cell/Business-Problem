import pandas as pd
import numpy as np
import yaml
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
import joblib
import os
import logging

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DataPreprocessor:
    def __init__(self, config_path='config/config.yaml'):
        with open(config_path, 'r') as f:
            self.config = yaml.safe_load(f)
        
        self.config_data = self.config['data']
        self.config_model = self.config['model']
        
        # Create directories
        os.makedirs('data/processed', exist_ok=True)
    
    def load_data(self):
        """Load raw data"""
        df = pd.read_csv(self.config_data['raw_path'])
        logger.info(f"Loaded data: {df.shape}")
        return df
    
    def feature_engineering(self, df):
        """Add engineered features"""
        df_eng = df.copy()
        
        # Area per bedroom
        df_eng['area_per_bedroom'] = df_eng['Area'] / (df_eng['Bedrooms'] + 1)  # +1 avoid div0
        
        # Age categories
        df_eng['age_category'] = pd.cut(df_eng['Age'], 
                                      bins=[-1, 5, 15, 30, 100], 
                                      labels=['New', 'Recent', 'Mature', 'Old'])
        
        # Bathrooms per bedroom
        df_eng['bath_per_bed'] = df_eng['Bathrooms'] / (df_eng['Bedrooms'] + 1)
        
        logger.info(f"Engineered features added: {df_eng.shape}")
        return df_eng
    
    def create_preprocessor(self):
        """Create preprocessing pipeline"""
        numeric_features = self.config_model['numeric_features'] + ['area_per_bedroom', 'bath_per_bed']
        categorical_features = self.config_model['categorical_features'] + ['age_category']
        
        numeric_transformer = Pipeline(steps=[
            ('scaler', StandardScaler())
        ])
        
        categorical_transformer = Pipeline(steps=[
            ('onehot', OneHotEncoder(handle_unknown='ignore', drop='first'))
        ])
        
        preprocessor = ColumnTransformer(
            transformers=[
                ('num', numeric_transformer, numeric_features),
                ('cat', categorical_transformer, categorical_features)
            ])
        
        return preprocessor, numeric_features, categorical_features
    
    def preprocess_and_split(self):
        """Full preprocessing pipeline"""
        df = self.load_data()
        df = self.feature_engineering(df)
        
        # Drop ID and target
        X = df.drop(columns=[self.config_model['target_col'], 'Property_ID'])
        y = df[self.config_model['target_col']]
        
        preprocessor, _, _ = self.create_preprocessor()
        
        # Save preprocessor
        joblib.dump(preprocessor, 'models/preprocessor.joblib')
        
        # Train-test split
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=self.config_model['test_size'], 
            random_state=self.config_model['random_state']
        )
        
        # Transform
        X_train_proc = preprocessor.fit_transform(X_train)
        X_test_proc = preprocessor.transform(X_test)
        
        # Save processed data
        pd.DataFrame(X_train_proc).to_csv(self.config_data['processed_path'].replace('.csv', '_train.csv'), index=False)
        pd.DataFrame(X_test_proc).to_csv(self.config_data['processed_path'].replace('.csv', '_test.csv'), index=False)
        
        logger.info("Preprocessing complete!")
        return X_train_proc, X_test_proc, y_train, y_test, preprocessor

if __name__ == "__main__":
    preprocessor = DataPreprocessor()
    X_train, X_test, y_train, y_test, preproc = preprocessor.preprocess_and_split()

